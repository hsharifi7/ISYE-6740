"""
This is a sample solution code from Question 2
"""
import pandas as pd
import numpy as np
from sklearn.linear_model import LinearRegression
from sklearn import linear_model
import matplotlib.pyplot as plt
from sklearn.linear_model import Ridge, RidgeCV
from sklearn.model_selection import KFold, GridSearchCV, cross_validate, train_test_split, cross_val_score, validation_curve
from sklearn.metrics import mean_squared_error, r2_score
import warnings
warnings.filterwarnings("ignore")

df = pd.read_csv('copper-new.txt', sep="  ", header=None)
copper = np.loadtxt('copper-new.txt')

x = np.array(df[1]).reshape((-1, 1))
y = np.array(df[0]).reshape((copper.shape[0],1))

x_train, x_test, y_train, y_test = train_test_split(x, y, test_size = 0.25, 
                                                    random_state = 0, shuffle=True)

x_train = x_train.reshape((-1, 1))
x_test = x_test.reshape((-1, 1))

"""
Q1: Linear regression model
"""
LR_model = LinearRegression(normalize=True)
LR_model.fit(x_train, y_train)
print('intercept:', LR_model.intercept_)
print('slope:', LR_model.coef_)
print('fitted model is y_pred = ', LR_model.intercept_ ,'+', LR_model.coef_ ,'* x')

m = len(y_test) 
y_LR_pred = LR_model.predict(x_test)
LR_mse = np.sum((y_LR_pred - y_test)**2)/m
LR_rmse = np.sqrt(LR_mse/m)
print('Linear Regression MSE :', LR_mse, "And Linear Regression RMSE:", LR_rmse)

plt.scatter(x, y, color = 'blue') 
plt.plot(x_test, y_LR_pred, color = 'red') 
plt.title('Linear Regression')
plt.show()



"""
Q3: 5-fold cross validation
We consider the polynomial regression with degree of 10
Here the alpha is our regularization term parameter
"""
from sklearn.preprocessing import PolynomialFeatures


K_fold = KFold(n_splits= 5, shuffle=True, random_state=0)

RR_mse = []

poly = PolynomialFeatures(degree = 10)

alphas = np.arange(0.001,0.5,0.001)

for i in alphas:
#    print('alpha:', i)
    CV_mse = [] 
    RR_Model_CV = Ridge(alpha=i, normalize = True)

    for CV_train, CV_test in K_fold.split(x):
        x_CV_train, x_CV_test = x[CV_train], x[CV_test]
        y_CV_train, y_CV_test = y[CV_train], y[CV_test]
        x_CV_train_poly = poly.fit_transform(x_CV_train) 
        x_CV_test_poly = poly.fit_transform(x_CV_test)
        RR_Model_CV.fit(x_CV_train_poly, y_CV_train)
        y_CV_pred = RR_Model_CV.predict(x_CV_test_poly)
        theta = RR_Model_CV.coef_
        
        # penalized sum of error
        mse = np.sum((y_CV_pred - y_CV_test)**2)/len(y_CV_pred) + i*np.sum(theta**2)
#        print('Ridge Regression MSE:', mse)
        CV_mse.append(mse)
    RR_mse.append(np.mean(CV_mse))

plt.scatter(np.log(alphas), RR_mse)
plt.title('Ridge Regression MSE vs log lambda')
plt.show()

print("The optimal lambda is: ", alphas[np.asarray(RR_mse).argmin()])

"""
Q4: Compare the LR and nonlinear regression model
We consider the polynomial regression with degree of 10
"""
#Linear Regression
Check =400
x_check = np.array([Check]).reshape(1,-1)
LR_pred = LR_model.predict(x_check)[0]
print("Linear Regression predicted coefficent is ", LR_pred)

# Polynomial Regression (n=10)
x_check_poly = poly.fit_transform(x_check)

x_new = poly.fit_transform(x_train)

# ridge regresion model with parameter 0.004
RR_Model_opt = Ridge(alpha=0.004, normalize = True)
RR_Model_opt.fit(x_new,y_train)


RR_pred = RR_Model_opt.predict(x_check_poly)[0]
print("Polynomial Regression with ridge regression predicted coefficent is ", RR_pred)

xx = np.linspace(0,x.max()+1).reshape(-1,1)
#xx= np.linspace(0,850,600).reshape((600,1))
plt.plot(xx, RR_Model_opt.predict(PolynomialFeatures(degree=10).fit_transform(xx)), label="Degree %d, alpha=%f" %(10,0.004))
plt.scatter([Check], LR_pred, c='purple', marker='*', s=200) 
plt.scatter([Check], RR_pred, c='red', marker='*', s=200) 
plt.legend(loc = 'lower right')
plt.plot(x,y, 'bo')
plt.xlabel('temperature')
plt.ylabel('coefficient')
plt.title('Linear Regression VS Ridge Regression')
plt.show()