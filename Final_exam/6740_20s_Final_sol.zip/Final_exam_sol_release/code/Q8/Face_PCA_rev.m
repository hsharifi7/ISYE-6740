clear;
close all;

data = [];
files01=dir('yalefaces/subject01*.*');
files14=dir('yalefaces/subject14*.*');

%% reading test images
fname = files01(1).name;
img = imread(['yalefaces/',fname]);
image_down = img(1:4:end, 1:4:end);
test01 = double(image_down(:));

fname = files14(1).name;
img = imread(['yalefaces/',fname]);
image_down = img(1:4:end, 1:4:end);
test14 = double(image_down(:));

%% reading training image
train01 = [];
train14 = [];
for ii = 2:11
    fname = files01(ii).name;
    img = double(imread(['yalefaces/',fname]));
    image_down = img(1:4:end, 1:4:end);
    train01 = [train01, image_down(:)];
    
    if ii<11    % note the number of sub14 img is changed
        fname = files14(ii).name;
        img = double(imread(['yalefaces/',fname]));
        image_down = img(1:4:end, 1:4:end);
        train14 = [train14, image_down(:)];
    end
end
train01 = double(train01);
train14 = double(train14);

% [v01, d01, w01]  = svd(train01);
% [v14, d14, w14] = svd(train14);

% %% eigendecomposition
[v01, d01] = eig(train01'*train01);
[v14, d14] = eig(train14'*train14);

%% display eigface
figure;
eigface01 = [];
for ii = 1:6
    imageout = train01 * v01(:, end-ii+1);
    eigface01 = [eigface01, imageout];
    subplot(2,3,ii)
    imshow(reshape(imageout, 61, 80), [min(imageout(:)) max(imageout(:))]);
    title(['#',num2str(ii),' eigenface'])
end
eigface14 = [];
figure;
for jj = 1:6
    imageout = train14 * v14(:, end-jj+1);
    eigface14 = [eigface14, imageout];
    subplot(2,3,jj)
    imshow(reshape(imageout, 61, 80), [min(imageout(:)),max(imageout(:))]);
    title(['#',num2str(jj), ' eigenface'])
end

%% 
% test image 01 on eigenface set 01
score_t1_e1 = test01'*eigface01(:,1)/norm(eigface01(:,1))/norm(test01');

% test image 01 on eigenface set 14
score_t1_e14 = test01'*eigface14(:,1)/norm(eigface14(:,1))/norm(test01');

% test image 14 on eigenface set 01
score_t14_e1 = test14'*eigface01(:,1)/norm(eigface01(:,1))/norm(test14');

% test image 14 on eigenface set 14
score_t14_e14 = test14'*eigface14(:,1)/norm(eigface14(:,1))/norm(test14');



[score_t1_e1 score_t1_e14; score_t14_e1 score_t14_e14]

[test01'*eigface01(:,1) test01'*eigface14(:,1); test14'*eigface01(:,1) test14'*eigface14(:,1)]

