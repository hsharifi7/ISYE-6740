clear;
[s, t] = readvars('edges.txt');
[nodeid, nodename, ground_truth] = readvars('nodes.txt');
len = size(nodeid);

% create graph
G = simplify(graph(s, t));

% adjency matrix
A = adjacency(G);

% diagonal matrix
D = sum(A, 2);

% find index for isolated nodes and remove it
index = find(D==0);
D(index) = [];
G = rmnode(G, index);

% create laplacian
L = laplacian(G);
L = full(L);
[V, D] = eig(L);

% sort the eigenvalue, eigenvector
[D,idx]=sort(diag(D));
V = V(:, idx);

% Take the first two eigenvector
V = V(:,1:2);

% Own testing of the idx produce
% [idx2, C3] = kmeans(V, 2); 
% running kmeans on it
cno = 2;
x = V';

% number of data points to work with;
m = size(x, 2);

% set the seed
rng(100);
% randomly select centroid,
new_centroid = x(:, randsample(size(x,2),cno));

c = zeros(size(new_centroid));

% iteration variables
iterno = 1000;
iter = 0;
labels =2;

% check is the difference in norm2 is less than threshold, or already
% have enough iteration
while (norm(c' - new_centroid')^2) > 0.0001 && (iter < iterno)
    iter = iter + 1;
    
    % update centroid
    c = new_centroid;
    
    %disp(new_centroid);
    
    % norm2 of the centroids;
    c2 = sum(c.^2, 1);
    
    % for each data point, computer max_j -2 * x' * c_j + c_j^2;
    tmpdiff = bsxfun(@minus, 2*x'*c, c2);
    
    % returning column vector containing labels
    [~, labels] = max(tmpdiff, [], 2);
    
    % update data assignment matrix;
    P = sparse(1:m, labels, 1, m, cno, m);
    count = sum(P, 1);
    
    % recompute centroids;
    new_centroid = bsxfun(@rdivide, x*P, count);
    
    % handle "Nan", reduce the matrix size
    c(:, any(isnan(new_centroid), 1)) = [];
    new_centroid(:, any(isnan(new_centroid), 1)) = [];
end

class = labels;
% change to 0, 1 label
class = class - 1;
centroid = new_centroid';

% I only considered those points still being clusters
% remove from the ground truth those index not being clusters
ground_truth(index) = [];

% false classification
false_classification = 1 - length(find(ground_truth == class))/length(ground_truth)



