clear
T = readtable('food-consumption.csv','ReadRowNames',true,'ReadVariableNames',true);
T = rmmissing(T);
data = table2array(T);                      
countrynames = T.Properties.RowNames;        
foodnames = T.Properties.VariableNames;
Anew= data; 
[m,n]=size(Anew);
stdA = std(Anew, 1, 1); 
Anew = Anew * diag(1./stdA); 
Anew = Anew'; 
mu=sum(Anew,2)./m;
xc = bsxfun(@minus, Anew, mu); 
                 
C = xc * xc' ./ m; 
k = 2; 
[W, S] = eigs(C, k); 

dim1 = W(:,1)' * xc ./ sqrt(S(1,1));
dim2 = W(:,2)' * xc ./ sqrt(S(2,2));

q2b = figure;
q2c = figure;

% Q2b
figure(q2b);
z = zeros(1,20);
plot(z+1 , W(:,1)', 'o');
text(z+1.1, W(:,1)', foodnames,'FontSize',5,'VerticalAlignment','bottom')

hold on;

plot(z+2 , W(:,2)', 'x')
text(z+2.1, W(:,2)', foodnames,'FontSize',5,'VerticalAlignment','bottom')
xlim([0 3])
set(gca,'xtick',[])
legend('PC1','PC2')

% Q2c
figure(q2c);
plot(dim1,dim2,'o'); 
text(dim1 ,dim2,countrynames,'FontSize',7,'VerticalAlignment','bottom');  
% plot([z;W(:,1)'],[z;W(:,2)'],'r');  
% text(W(:,1),W(:,2),foodnames,'FontSize',7,'VerticalAlignment','bottom','HorizontalAlignment','right','color','red');
% grid on; axis equal
% xlabel('c_1'); ylabel('c_2')


